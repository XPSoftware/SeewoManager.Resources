'use strict';

var remoteVideo = document.getElementById('remoteVideo');
const maskEle = document.getElementById('mask');


let videoWidth;
let videoHeight;
let lastAngle = 0;
let specialAngle = 0;
let fullScreen = true;
let videoResized = false;

let localStream;

let pc;
let iceServer = {
};

var localCandidates = new Array();
var localSdp;
// 是否使用'动态candidate'方案，取决于 setOffer 的调用中是否包含远端的 candidates
// 如果包含，则不使用'动态candidate'方案，在收集完本地的Candidates或超时后调用callSetAnswer
// 如果不包含，则使用'动态candidate'方案，收集到Answer后立即调用callSetAnswerOnly,每收集到一个Candidate则调用callSetCandidate
let dynamicCandidate = false;

var timeoutId;

// 上报数据相关
let uid;
// 正式环境域名：https://grail.cvte.com，测试环境域名：https://apm.gz.cvte.cn
const host = "https://grail.cvte.com";
const requestUrl = "/grail/api/report/raw";
const dataId = "en_mobile_ed03d246";
let lastTotalFreezeDuration = 0;
let statsInterval;
let lastFixedStreamOrientation = false;

(async () => {
    await CefSharp.BindObjectAsync("externalAsync");
    console.log("Bind callback object");
})();

// 客户端调用Web函数
window.setIceServer = function (dataStr) {
    iceServer = JSON.parse(dataStr);
    try{
        var username = iceServer.iceServers[0].username;
        console.log('username:', username);
        uid = username.match('.*:(.*)\@.*')[1];
        console.log('uid:', uid);
    }
    catch(e){
        console.error('获取 uid 失败', e);
    }
}

window.setOffer = async function (dataStr) {

    console.log("setOffer");
    var data = JSON.parse(dataStr);
    var remoteSdp = data.sdp;
    var remoteCandidates = data.candidates;

    var remoteOffer = {
        type: 'offer',
        sdp: remoteSdp
    };

    initPeerConnection();

    await pc.setRemoteDescription(remoteOffer);

    console.log('SetOffer setRemoteDescription success');

    if(remoteCandidates !== null){
        // Add Remote Candidates
        remoteCandidates.forEach(function (candidate, index) {
            pc.addIceCandidate(new RTCIceCandidate(JSON.parse(candidate))).then(function () {
                console.log('SetOffer addIceCandidate success:', candidate);
            });
        });
    }
    

    var answer = await pc.createAnswer();

    var localParser = parse(answer.sdp);
    console.log('localParser', localParser);

    var medias = localParser.media;
    for (let index = 0; index < medias.length; index++) {
        var media = medias[index];
        if (media.type === 'video') {
            var fmtps = media.fmtp;
            fmtps.forEach(function (fmtp) {
                var config = fmtp.config;
                if (config.indexOf('profile-level-id=42e01f') > -1) {
                    fmtp.config = config.replace('profile-level-id=42e01f', 'profile-level-id=42e032');
                }
                if (config.indexOf('profile-level-id=42001f') > -1) {
                    fmtp.config = config.replace('profile-level-id=42001f', 'profile-level-id=420032');
                }

                if (config.indexOf('profile-level-id=4d001f') > -1) {
                    fmtp.config = config.replace('profile-level-id=4d001f', 'profile-level-id=4d0032');
                }
                if (config.indexOf('profile-level-id=64001f') > -1) {
                    fmtp.config = config.replace('profile-level-id=64001f', 'profile-level-id=640032');
                }
            });
            break;
        }
    }

    var newSdp = write(localParser);
    console.log('newSdp:', newSdp);

    localSdp = newSdp;
    answer.sdp = newSdp;

    if(remoteCandidates === null || remoteCandidates.length == 0){
        dynamicCandidate = true;
        callSetAnswerOnly(localSdp);
    }

    await pc.setLocalDescription(answer);

    if(!dynamicCandidate){
        setIceTimeout(); //启动计时器
    }

    console.log('SetOffer setLocalDescription success');
}

window.setCandidates = function (dataStr){
    
    var data = JSON.parse(dataStr);
    // Add Remote Candidates
    data.candidates.forEach(function (candidate, index) {
        pc.addIceCandidate(new RTCIceCandidate(JSON.parse(candidate))).then(function () {
            console.log('setCandidates addIceCandidate success:', candidate);
        });
    });
}

window.closePeerConnection = function () {
    uninitPeerConnection();
}

window.rotate = (isFullScreen, angle, width, height, fixedStreamDirection) => {
    lastFixedStreamOrientation = fixedStreamDirection;
    // 过滤掉连续多次相同的旋转
    if(!videoResized 
        && isFullScreen === fullScreen
        && angle === lastAngle
        && width === window.outerWidth
        && height === window.outerHeight){
            return;
        }
    
    videoResized = false;
    console.log(`fullScreen:${isFullScreen} rotate ${angle} ${width} ${height} ${fixedStreamDirection}`)
    if(isFullScreen){
        if(videoWidth < videoHeight){
            // 竖流的情况，IOS 默认是竖流，安卓 可能是竖流
            if (angle === 90 || angle === 270) {
                var screenScale = Math.max(width, height) / Math.min(width, height);
                var videoScale = Math.max(videoWidth, videoHeight) / Math.min(videoWidth, videoHeight);
                var scale = 1;
                if(screenScale > videoScale){
                    // 屏幕是横屏或者竖屏
                    scale = width > height ? videoHeight / videoWidth : videoWidth / videoHeight;
                }
                else{
                    scale = width / height;
                }
                remoteVideo.style.transform = `rotate(${angle}deg) scale(${scale})`;
            }
            else if(angle === 180){
                remoteVideo.style.transform = `rotate(${angle}deg)`;
            }
            else{
                remoteVideo.style.transform = 'unset';
            }
        }
        else{
            // 横流的情况，安卓 可能是横流
            // 这里的逻辑只能处理角度为0时的横流，若角度为90或270，流也是横流，则会有问题（如折叠屏手机等）
            // 如果流的方向和窗口方向一致，只需要处理旋转角度
            if((width > height && videoWidth > videoHeight) || (width < height && videoWidth < videoHeight)){
                if(angle === 180){
                    remoteVideo.style.transform = `rotate(${angle}deg)`;
                }
                // 流方向是固定的，则按照旋转角度处理下；如果流方向不固定，即方向转了，流也跟着转，则不处理，走到最后的else分支
                else if (fixedStreamDirection && (angle === 90 || angle === 270)) {
                    var screenScale = Math.max(width, height) / Math.min(width, height);
                    var videoScale = Math.max(videoWidth, videoHeight) / Math.min(videoWidth, videoHeight);
                    var scale = 1;
                    if(screenScale >= videoScale){
                        // 屏幕是横屏或者竖屏
                        scale = width > height ? videoHeight / videoWidth : videoWidth / videoHeight;
                    }
                    else{
                        scale = width / height;
                    }
                    remoteVideo.style.transform = `rotate(${angle}deg) scale(${scale})`;
                }
                else{
                    remoteVideo.style.transform = 'unset';
                }
            }
            else{
                if (angle === 90 || angle === 270) {
                    var screenScale = Math.max(width, height) / Math.min(width, height);
                    var videoScale = Math.max(videoWidth, videoHeight) / Math.min(videoWidth, videoHeight);
                    var scale = 1;
                    if(screenScale > videoScale){
                        // 屏幕是横屏或者竖屏
                        scale = width > height ? videoHeight / videoWidth : videoWidth / videoHeight;
                    }
                    else{
                        scale = width / height;
                    }
                    remoteVideo.style.transform = `rotate(${angle}deg) scale(${scale})`;
                }
                else if(angle === 180){
                    remoteVideo.style.transform = `rotate(${angle}deg)`;
                }
                else{
                    remoteVideo.style.transform = 'unset';
                }
            }
        }
    }
    else{
        // 如果流的方向和窗口方向一致，只需要处理旋转角度
        if((width > height && videoWidth > videoHeight) || (width < height && videoWidth < videoHeight)){
            if(angle === 180){
                remoteVideo.style.transform = `rotate(${angle}deg)`;
            }
            else{
                remoteVideo.style.transform = 'unset';
            }
        }
        else{
            if (angle === 90 || angle === 270) {
                remoteVideo.style.transform = `rotate(${angle}deg) scale(${Math.max(width, height) / Math.min(width, height)})`;
            }
            else{
                var actualAngle = lastAngle === 0 || lastAngle === 180 ? lastAngle : lastAngle + 180;
                remoteVideo.style.transform = `rotate(${actualAngle}deg) scale(${height / width}`;
            }
        }
    }
    
    lastAngle = angle;
    fullScreen = isFullScreen;

    maskEle.style.visibility = fullScreen ? 'hidden' : 'visible';
}

remoteVideo.addEventListener("playing", () => {
    console.log(`callSetVideoRatio ${remoteVideo.videoWidth} / ${remoteVideo.videoHeight} = ${remoteVideo.videoWidth / remoteVideo.videoHeight}`);
    externalAsync.setVideoRatio(remoteVideo.videoWidth / remoteVideo.videoHeight);
  });

remoteVideo.addEventListener("resize", () => {
    console.log(`onresize ${remoteVideo.videoWidth} * ${remoteVideo.videoHeight}`);
    videoWidth = remoteVideo.videoWidth;
    videoHeight = remoteVideo.videoHeight;
    videoResized = true;
    window.rotate(fullScreen, lastAngle, window.outerWidth, window.outerHeight, lastFixedStreamOrientation);
  });

window.getReceiveBytesCount = async function(){
    let receiver = pc.getReceivers()[0];
    if(!receiver) {
        console.log("cant get receiver!");
        return -1;
    }
    let bytes = -2;
    try{
        await receiver.getStats().then(res => {
            res.forEach(report => {
              if (report.type === 'candidate-pair') {
                if (report.state === 'succeeded') {
                    bytes = report.bytesReceived;
                    throw new Error(`find reporter ${bytes}`);
                }
              }
            });
          });
    }catch(e){
    }
    return bytes;
}



// Web调用PC端
function callSetAnswer(localSdp, localCandidates) {
    console.log("callSetAnswer", localCandidates);

    var data = {
        answer: localSdp,
        candidates: localCandidates
    };

    var dataStr = JSON.stringify(data);
    externalAsync.setAnswer(dataStr);
}

function callSetAnswerOnly(localSdp) {
    console.log("callSetAnswerOnly", localSdp);

    var data = {
        answer: localSdp,
    };
    var dataStr = JSON.stringify(data);
    externalAsync.setAnswerOnly(dataStr);
}

function callSetCandidate(candidate) {
    console.log("callSetCandidate", candidate);

    var data = {
        candidate: candidate,
    };
    var dataStr = JSON.stringify(data);
    externalAsync.setCandidate(dataStr);
}

function callNotifyConnectionState(state) {
    var data = {
        state: state,
    };

    var dataStr = JSON.stringify(data);

    externalAsync.notifyConnectionState(dataStr);
}

// 其他
function initPeerConnection() {

    console.log("initPeerConnection");
    uninitPeerConnection();

    pc = new RTCPeerConnection(iceServer);

    pc.ontrack = function (e) {
        gotRemoteStream(e);
    };

    pc.onsignalingstatechange = function (e) {
        console.log('signalingState', pc.signalingState);
    }

    pc.onconnectionstatechange = function (e) {
        var state = pc.connectionState;
        console.log('connectionState', state);
        callNotifyConnectionState(state);
        if(state === "connected"){
            startReportTimer();
        }
        else if(state === "disconnected"){
            stopReportTimer();
        }
    };

    pc.onicegatheringstatechange = function () {
        var state = pc.iceGatheringState;
        console.log('iceGatheringState', state);
        if (state === 'complete') {
            console.log('localCandidates', localCandidates);

            console.log('ice gathering complete, and clear ice timer');
            clearIceTimeout();
            if(!dynamicCandidate){
                callSetAnswer(localSdp, localCandidates); //回调PC端
            }
        }
    };

    pc.onicecandidate = function (e) {
        if (e.candidate) {
            console.log('onicecandidate:', e.candidate);
            var candidate = JSON.stringify(e.candidate);
            localCandidates.push(candidate);
            if(dynamicCandidate){
                callSetCandidate(candidate);
            }
        }
    };
}

function uninitPeerConnection() {
    if (pc) {
        pc.close();
        pc = null;
        localCandidates = null;
        localSdp = null;
        iceServer = null;
    }
}

function gotRemoteStream(e) {
    console.log('Received remote stream');
    console.log(e.track);
    console.log(e.streams[0]);
    if (remoteVideo.srcObject !== e.streams[0]) {
        remoteVideo.srcObject = e.streams[0];
    }
}

function clearIceTimeout() {
    if (timeoutId) {
        console.log('call clearIceTimeout');
        window.clearTimeout(timeoutId); //先清除ICE收集计时器
        timeoutId = null;
    }
}

function setIceTimeout() {
    clearIceTimeout();  //先尝试清除ICE收集计时器
    console.log('call setIceTimeout');
    timeoutId = setTimeout(() => {
        console.log('ice gather timeout, force call setAnswer');
        if(!dynamicCandidate){
            callSetAnswer(localSdp, localCandidates); //回调PC端
        }
    }, 2000);
}

function startReportTimer(){
    statsInterval = setInterval("reportData()",5000);
}

function stopReportTimer(){
    clearInterval(statsInterval);
}

async function reportData(){
    var data = await getReportData();
    report("rtc_cast_latency", data.latency);
    //report("rtc_cast_freeze", data.freeze);
}

function report(category3,value){
    const url = `${host}${requestUrl}`;
    const data = [
        {
            "uid":uid,
            "timestamp":new Date().getTime(),
            "class":"performance",
            "category3":category3,
            "value":value,
        }
    ];
    const dataStr = JSON.stringify(data);
    console.log(dataStr);
    const otherParam = {
        headers:{
            'Content-Type':'application/json',
            'refer': 'http://easinote.seewo.com',
            'X-Data-Id':dataId
        },
        body:dataStr,
        method:'POST'
    };
    fetch(url, otherParam)
    .then(data1=>{console.log(`data:${data1}`)})
    .then(res=>{console.log(`res:${res}`)})
    .catch(error=>console.error(`fetch error:${error}`));
}

async function getReportData(){
    let inboundStats;
    try{
        await pc.getStats().then(res=>{
            const arr = Array.from(res.values());
            for (let i = 0; i < arr.length; i++) {
                if(arr[i].type === "inbound-rtp" && arr[i].kind === "video"){
                    inboundStats = arr[i];
                    break;
                }
            }
        })
    }
    catch(e){
        console.log(e);
    }
    if(inboundStats === null) return;
    // 粗略计算当前延时,便于后台观察延时的趋势，单位毫秒
    var decodelatency = inboundStats.totalDecodeTime * 1000 / inboundStats.framesDecoded;
    //平均每帧之间的时间间隔,单位毫秒
    const meanInterframeDelay = inboundStats.totalInterFrameDelay * 1000 / inboundStats.framesDecoded;
    const variance = Math.abs(inboundStats.totalSquaredInterFrameDelay * 1000 / inboundStats.framesDecoded - Math.pow(meanInterframeDelay, 2));
    var interFrameDelayStDev = Math.sqrt(variance);
    var jitterlatency = inboundStats.jitterBufferDelay * 1000 / inboundStats.jitterBufferEmittedCount;
    console.log(`decodelatency:${decodelatency},interFrameDelayStDev:${interFrameDelayStDev},jitterlatency:${jitterlatency}`);
    // // 当前总的卡顿时间，单位毫秒
    // var totalFreezeDuration = inboundStats.totalFreezesDuration * 1000;
    // // 与上次上报之间的卡顿时间，单位毫秒
    // var freezeDuration = totalFreezeDuration - lastTotalFreezeDuration;
    // lastTotalFreezeDuration = totalFreezeDuration;
    return {"latency":decodelatency + interFrameDelayStDev + jitterlatency, "freeze": 0};
}